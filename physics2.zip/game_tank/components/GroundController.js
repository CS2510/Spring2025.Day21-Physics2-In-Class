class GroundController extends Component {
  start() {
    Events.addEventListener("Collision", this)
  }
  handleEvent(type, event){
    if(event.target == this.parent){
      event.source.parent.destroy()
      Events.handleEvent("Miss", {})
    }
  }
}