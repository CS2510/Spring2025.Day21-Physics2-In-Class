class TargetController extends Component {
  constructor(points = 1) {
    super()
    this.points = points
    
  }
  start() {
    Events.addEventListener("Collision", this)
  }
  handleEvent(type, event){
    if(type == "Collision" && event.target == this.parent){
      event.source.parent.destroy()
      Events.handleEvent("ScoreChange", {scoreChange: this.points})
    }
  }
}