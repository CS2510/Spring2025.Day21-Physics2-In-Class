class TurretController extends Component {
  start() {
    this.angle = -Math.PI / 2
    this.turretLength = 50
    this.rotationSpeed = 1
    this.bulletSpeed = 250
  }
  update() {
    if (Input.keysdown.includes("ArrowLeft")) {
      this.angle -= this.rotationSpeed * Time.deltaTime
    }
    if (Input.keysdown.includes("ArrowRight")) {
      this.angle += this.rotationSpeed * Time.deltaTime
    }
    if (this.angle > 0)
      this.angle = 0

    if (this.angle < -Math.PI)
      this.angle = -Math.PI

    this.transform.x2 = Math.cos(this.angle) * this.turretLength + this.transform.x
    this.transform.y2 = Math.sin(this.angle) * this.turretLength + this.transform.y

    if(Input.keysUpThisFrame.includes("Space")){
      let bullet = new BulletGameObject("Bullet Game Object")
      
      bullet.findComponent(RigidBody).vx = Math.cos(this.angle) * this.bulletSpeed
      bullet.findComponent(RigidBody).vy = Math.sin(this.angle) * this.bulletSpeed
      Engine.currentScene.addGameObject(bullet, this.transform.x2, this.transform.y2)
    }

  }

}