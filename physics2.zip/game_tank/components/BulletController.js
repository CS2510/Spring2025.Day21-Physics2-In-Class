class BulletController extends Component {
  update() {
   if(this.transform.y > 600){
    this.parent.destroy()
    Events.handleEvent("Miss", {})
   }

   for(let gameObject of Engine.currentScene.gameObjects){
    if(this.parent != gameObject){
      if(Collisions.inCollision(this.parent, gameObject)){
        Events.handleEvent("Collision", {source: this, target: gameObject})
      }
    }
   }
  }
}