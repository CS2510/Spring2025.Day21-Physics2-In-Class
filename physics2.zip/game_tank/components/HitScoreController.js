class HitScoreController extends Component{
  start(){
    this.score = 0
    Events.addEventListener("ScoreChange", this)
  }
  update(){
  }
  handleEvent(type, event){
    this.score += event.scoreChange
    this.parent.findComponent(Text).text = "Score: " + this.score
  }
}