class MissScoreController extends Component {
  start() {
    this.misses = 0
    Events.addEventListener("Miss", this)
  }
  update() {
    this.parent.findComponent(Text).text = "Misses: " + this.misses
  }
  handleEvent(type, event){
    this.misses++
  }
}