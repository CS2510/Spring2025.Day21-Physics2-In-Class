class Scene01 extends Scene{
  start(){
    this.addGameObject(new GroundGameObject("Ground Game Object"), 600, 410, 5000, 200)
    this.addGameObject(new TankGameObject("Tank Game Object"), 300, 300, 90, 40)
    this.addGameObject(new TurretGameObject("Turret Game Object"), 300, 300, 300, 250)
    this.addGameObject(new TargetGameObject("Target Game Object"), 600, 300, 20)
    this.addGameObject(new TargetGameObject("Target Game Object", 2), 800, 300, 20)
    this.addGameObject(new HitScoreGameObject("Hit Score Game Object"), 10, 60)
    this.addGameObject(new MissScoreGameObject("Miss Score Game Object"), 10, 90)
    this.addGameObject(new GameObject("Description Game Object").addComponent(new Text("black", "20px Times", "Hit the blue targets to score")), 10, 30)
  }
}