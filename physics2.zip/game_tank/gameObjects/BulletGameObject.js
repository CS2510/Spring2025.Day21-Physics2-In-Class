class BulletGameObject extends GameObject{
  constructor(name){
    super(name)
    this.addComponent(new Rectangle("black", "transparent", 0))
    this.addComponent(new BulletController())
    this.addComponent(new RigidBody(64))
  }
  start(){
    this.transform.w = 5
    this.transform.h = 5
  }
}