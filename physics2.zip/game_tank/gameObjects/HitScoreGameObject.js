class HitScoreGameObject extends GameObject{
  start(){
    this.addComponent(new Text("Black", "30px Times", "Score Text"))
    this.addComponent(new HitScoreController())
  }
}