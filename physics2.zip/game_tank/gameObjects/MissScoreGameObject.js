class MissScoreGameObject extends GameObject{
  start(){
    this.addComponent(new Text("black", "30px Times", "Misses Text"))
    this.addComponent(new MissScoreController())
  }
}