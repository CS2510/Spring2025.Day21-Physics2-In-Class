class TankGameObject extends GameObject{
  start(){
    this.addComponent(new Rectangle("#FF0000", "transparent", 0))

  }
}