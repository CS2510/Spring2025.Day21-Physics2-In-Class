class TurretGameObject extends GameObject{
  start(){
    this.addComponent(new Line("#FF9999", 5))
    this.addComponent(new TurretController())
  }
}