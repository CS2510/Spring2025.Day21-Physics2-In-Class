class TargetGameObject extends GameObject{
  constructor(name, points=1){
    super(name)
    this.points = points
  }
  start(){
    this.addComponent(new Circle("blue", "lightblue", 2))
    this.addComponent(new TargetController(this.points))
  }
}