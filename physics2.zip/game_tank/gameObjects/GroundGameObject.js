class GroundGameObject extends GameObject{
  start(){
    this.addComponent(new Rectangle("brown", "transparent", 2))
    this.addComponent(new GroundController())
  }
}