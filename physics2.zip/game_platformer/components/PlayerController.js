class PlayerController extends Component {
  start() {
    this.isGrounded = false;
    this.speed = 50
    this.rigidBody = this.parent.findComponent(RigidBody)
    //Store double jump variable
  }
  update() {
    //Kill the player if below a certain amount
    if(this.transform.y > 400) Engine.nextScene = new Scene01()

    //Reset isGrounded
    this.isGrounded = false

    this.rigidBody.vx = 0
    //Set velocity based on keys
    if(Input.keysdown.includes("ArrowLeft")) this.rigidBody.vx = -50
    if(Input.keysdown.includes("ArrowRight")) this.rigidBody.vx = 50

    //Find the edges of the player
    let [pl, pr, pt, pb] = Collisions.getEdgesOfRectangle(this.parent)

    //If there was a last collision in Y
    if(this.rigidBody.lastCollisionY){
      // - Get edges of the last collision object
      let [cl, cr, ct, cb] = Collisions.getEdgesOfRectangle(this.rigidBody.lastCollisionY)
      // - If the player is above the platform
      if(pb <= ct){
        // - - Ground the player
        this.isGrounded = true
        // - - Move the player up slightly
        this.transform.y -= .0001
        // - - Set y velocity to 0
        this.rigidBody.vy = 0
        //- - Clear double jump
      }
      //? Handle when you hit something with your head
      else{
        this.rigidBody.vy = 10
      }
    }
    
    //If the player is grounded
    if(this.isGrounded){
      // - Check for jump button
      if(Input.keysDownThisFrame.includes("ArrowUp")){
        // - - Set grounded to false
        this.isGrounded = false
        // - - Give the player an impulse velocity in y
        this.rigidBody.vy = -100
      }
    }
    //?Check for double jump conditions
      // - Check for jump button
        // - - Set grounded to false
        // - - Give the player an impulse velocity in y
  }
}