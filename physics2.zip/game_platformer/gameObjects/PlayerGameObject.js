class PlayerGameObject extends GameObject {
  start() {
    this.addComponent(new Rectangle("red", "transparent", 0))
    this.addComponent(new PlayerController())
    this.addComponent(new RigidBodyPlatformer(200))

  }
}