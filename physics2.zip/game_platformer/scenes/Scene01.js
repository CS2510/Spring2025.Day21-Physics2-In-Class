class Scene01 extends Scene{
  start(){
    this.addGameObject(new PlayerGameObject("Player Game Object"), 300, 285, 10, 20)
    this.addGameObject(new PlatformGameObject("Platform Game Object"), 300, 300, 100, 10)
    this.addGameObject(new PlatformGameObject("Platform Game Object"), 550, 295, 100, 10)
    this.addGameObject(new PlatformGameObject("Platform Game Object"), 500, 300, 100, 10)
    this.addGameObject(new PlatformGameObject("Platform Game Object"), 400, 335, 100, 10)
  }
}