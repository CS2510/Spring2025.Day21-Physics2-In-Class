class DynamicLineGameObject extends GameObject{
  start(){
    this.addComponent(new Line("black", 1))
    this.addComponent(new LineController())
    
  }
}