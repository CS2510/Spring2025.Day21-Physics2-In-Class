class DynamicRectangleGhostGameObject extends GameObject {
  start(){
    this.addComponent(new Rectangle("transparent", "purple", 1))
    this.addComponent(new GhostController())
  }
  
}