class DynamicRectangleGameObject extends GameObject{
  start(){
    this.addComponent(new Rectangle("#0000FF33", "lightblue", 1))
    this.addComponent(new RectangleController())
  }
}