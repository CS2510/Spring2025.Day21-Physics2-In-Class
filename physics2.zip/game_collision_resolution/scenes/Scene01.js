class Scene01 extends Scene {
  start() {
    let cx = 400
    let cy = 400
    let d = 300
    let w = 50
    let h = 50

    this.addGameObject(new GameObject("Static Center Rectangle Game Object").addComponent(new Rectangle("transparent", "green", 1)), cx, cy, w, h)
    this.addGameObject(new GameObject("Static Center Rectangle Game Object").addComponent(new Circle("transparent", "green", 1)), cx, cy, w / 2)

    this.addGameObject(new GameObject("Static Offset Game Object").addComponent(new Rectangle("red", "transparent", 1)), cx + d, cy + d, w / 8, h / 8)
    this.addGameObject(new GameObject("Static Offset Game Object").addComponent(new Rectangle("red", "transparent", 1)), cx, cy + d, w / 4, h / 4)
    this.addGameObject(new GameObject("Static Offset Game Object").addComponent(new Rectangle("red", "transparent", 1)), cx - d, cy + d, w / 2, h / 2)
    this.addGameObject(new GameObject("Static Offset Game Object").addComponent(new Rectangle("red", "transparent", 1)), cx - d, cy, w, h)
    this.addGameObject(new GameObject("Static Offset Game Object").addComponent(new Rectangle("red", "transparent", 1)), cx - d, cy - d, w * 2, h * 2)

    this.addGameObject(new GameObject("Static Offset Game Object").addComponent(new Circle("red", "transparent", 1)), cx, cy - d, w)
    this.addGameObject(new GameObject("Static Offset Game Object").addComponent(new Circle("red", "transparent", 1)), cx + d, cy - d, w / 2)
    this.addGameObject(new GameObject("Static Offset Game Object").addComponent(new Circle("red", "transparent", 1)), cx + d, cy, w / 4)

    this.addGameObject(new GameObject("Static Offset Game Object").addComponent(new Line("red", "transparent", 1)), cx + d / 2, cy, cx + d / 2 + w, cy + h)
    this.addGameObject(new GameObject("Static Offset Game Object").addComponent(new Line("red", "transparent", 1)), cx - d / 2, cy, cx - d / 2 + w, cy + h)
    this.addGameObject(new GameObject("Static Offset Game Object").addComponent(new Line("red", "transparent", 1)), cx, cy - d / 2, cx + w, cy - d / 2 + h)
    this.addGameObject(new GameObject("Static Offset Game Object").addComponent(new Line("red", "transparent", 1)), cx, cy + d / 2, cx + w, cy + d / 2 + h)


    this.addGameObject(new DynamicRectangleGameObject("Dynamic Rectangle Game Object"), cx, cy, w, h)
    this.addGameObject(new DynamicRectangleGhostGameObject("Dynamic Rectangle Ghost Game Object"), cx, cy, w, h)

    this.addGameObject(new GameObject("Dynamic Circle Game Object").addComponent(new Circle("rgba(255, 0, 255, .2)", "transparent", 1)).addComponent(new RectangleController()), 0, 0, w / 2)
    this.addGameObject(new GameObject("Dynamic Circle Ghost Game Object").addComponent(new Circle("transparent", "purple", 1)).addComponent(new GhostController()), 0, 0, w / 2)

    this.addGameObject(new DynamicLineGameObject("Dynamic Line Game Object"), cx, cy, 500, 500)
  }
}