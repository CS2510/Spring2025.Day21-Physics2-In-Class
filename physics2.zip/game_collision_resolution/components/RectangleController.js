class RectangleController extends Component {

  update() {
    let lineGameObject = Engine.currentScene.findGameObject("Dynamic Line Game Object")
    let staticRectangleGameObject = Engine.currentScene.findGameObject("Static Center Rectangle Game Object")
    let offsetRectangleGameObjects = Engine.currentScene.findGameObjects("Static Offset Game Object")


    let x = Input.mouseX
    let y = Input.mouseY
    if (typeof x === 'undefined' || typeof y === 'undefined') //For frames before the mouse enters the window
      return

    this.transform.x = x
    this.transform.y = y
    let start = new Vector2(staticRectangleGameObject.transform.x, staticRectangleGameObject.transform.y)

    for (let offsetRectangleGameObject of offsetRectangleGameObjects) {
      Physics.resolvePrecise(start, this.parent, offsetRectangleGameObject, 8)
    }

  }
}