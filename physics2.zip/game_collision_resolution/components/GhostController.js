class GhostController extends Component{
  update() {
    let x = Input.mouseX
    let y = Input.mouseY
    if (typeof x === 'undefined' || typeof y === 'undefined')
      return

    this.transform.x = x
    this.transform.y = y
  }
}