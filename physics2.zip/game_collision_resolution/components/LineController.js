class LineController extends Component{
  start(){
   
   }
  update(){
    let x = Input.mouseX
    let y = Input.mouseY
    this.transform.x2 = x
    this.transform.y2 = y

  }

}