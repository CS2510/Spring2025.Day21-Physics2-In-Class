class Component{
    parent
    started
    constructor(){
        this.started = false;
    }
    get transform(){
        return this.parent.transform
    }
    start(){

    }
    update(){

    }
    draw(){

    }
}