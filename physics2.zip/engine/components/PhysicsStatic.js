class PhysicsStatic extends Component{
  
}