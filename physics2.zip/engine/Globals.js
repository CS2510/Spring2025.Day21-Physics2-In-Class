class Globals{
  
}