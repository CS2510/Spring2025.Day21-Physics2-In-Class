class Time{
    static msBetweenFrames = 20
    static fps = 1000 / Time.msBetweenFrames
    static deltaTime = Time.msBetweenFrames / 1000
    
}