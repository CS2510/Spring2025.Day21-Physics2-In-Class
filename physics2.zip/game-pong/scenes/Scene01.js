class Scene01 extends Scene{
  start(){
    this.addGameObject(new WallGameObject("Wall Game Object"), 50, 90, 400, 90)
    this.addGameObject(new WallGameObject("Wall Game Object"), 400, 90, 400, 200)
    this.addGameObject(new WallGameObject("Wall Game Object"), 50, 90, 50, 200)
    this.addGameObject(new WallGameObject("Wall Game Object"), 50, 200, 400, 200)
    this.addGameObject(new BallGameObject("Ball Game Object"), 250, 120, 10, 10)
    this.addGameObject(new GameObject("Description Game Object").addComponent(new Text("black", "20px Times", "Watch the ball bounce")), 10, 30)
  }
}