class Scene02 extends Scene{
  start(){
    this.addGameObject(new WallGameObject("Wall Game Object"), 250, 140, 250, 90)
    this.addGameObject(new WallGameObject("Wall Game Object"), 50, 290, 450, 290)
    this.addGameObject(new WallGameObject("Wall Game Object"), 250, 140, 50, 290)
    this.addGameObject(new WallGameObject("Wall Game Object"), 250, 90, 450, 290)
    this.addGameObject(new BallGameObject("Ball Game Object"), 260, 120, 10, 10)
    this.addGameObject(new GameObject("Description Game Object").addComponent(new Text("black", "20px Times", "Watch the ball bounce")), 10, 30)
  }
}