class WallGameObject extends GameObject{
  constructor(){
    super()
    this.addComponent(new Line("black", "black", 1))
    this.addComponent(new PhysicsStatic())
  }
}