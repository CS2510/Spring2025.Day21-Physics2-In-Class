class BallGameObject extends GameObject{
  constructor(){
    super()
    this.addComponent(new Circle("blue", "lightblue", 2))
    this.addComponent(new RigidBodyReflective(100))
    this.addComponent(new BallController())
  }
}