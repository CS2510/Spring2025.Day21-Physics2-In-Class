class BallController extends Component{
  start(){
    //Get the reflective rigid body
    this.rigidBody = this.parent.findComponent(RigidBodyReflective)
    //Set the speed of the ball
    let speed = 100
    //Set the angle of the ball's direction
    let angle = .1
    //Set the rigid body's velocity based on the speed and direction of the ball
    this.rigidBody.vx = Math.cos(angle)*speed
    this.rigidBody.vy = Math.sin(angle)*speed
  }
}